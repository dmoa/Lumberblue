function love.conf(t)
    t.window.title = "Ice Drop"
    t.window.width = 512
    t.window.height = 512
    t.window.icon = "assets/imgs/icon.png" 
end